import { MateriaSliderInterface } from 'src/app/tab1/materia-slider/interfaces/materia-slider.interface';

export const dadosMateria: MateriaSliderInterface[] = [
  {
    id: '1',
    nome: 'Matemática',
    image: 'https://imgur.com/2Mgw3hx.png'
  },
  {
    id: '2',
    nome: 'Portugues',
    image: 'https://imgur.com/QonskXB.png'
  },
  {
    id: '3',
    nome: 'Portugues',
    image: 'https://imgur.com/Xsboprd.png'
  },
  {
    id: '4',
    nome: 'Portugues',
    image: 'https://imgur.com/ss4jvd6.png'
  },
];
