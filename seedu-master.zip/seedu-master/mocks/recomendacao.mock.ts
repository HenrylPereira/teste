import { RecomendacaoSliderInterface } from 'src/app/tab1/recomendacao-slider/interfaces/recomendacao-slider.interface';

export const dadosRecomendacao: RecomendacaoSliderInterface[] = [
  {
    id: '1',
    nome: 'Enem',
    image: 'https://imgur.com/x0eTpQP.png'
  },
  {
    id: '2',
    nome: 'Portugues',
    image: 'https://imgur.com/67CugFg.png'
  }
];
