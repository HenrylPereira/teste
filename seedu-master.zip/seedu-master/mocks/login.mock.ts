import { LoginInterface } from 'src/app/login/interfaces/login.interface';

export const dadosLogin: LoginInterface[] = [
  {
    id: '1',
    email: 'henry.pereira@totvs.com.br',
    password: '2'
  },
  {
    id: '1',
    email: 'bruno@totvs.com.br',
    password: '123'
  }
];
