export interface MateriaSliderInterface {
  id: string;
  nome: string;
  image: string;
}

export type MateriaSlidersInterface = Array<MateriaSliderInterface>;
