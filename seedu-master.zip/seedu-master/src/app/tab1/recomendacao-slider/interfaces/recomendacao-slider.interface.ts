export interface RecomendacaoSliderInterface {
  id: string;
  nome: string;
  image: string;
}

export type RecomendacaoSlidersInterface = Array<RecomendacaoSliderInterface>;
