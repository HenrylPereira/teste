export interface ModuloGetInterface {
  id: string;
  title: string;
  duracao: string;
  svg: string;
}
