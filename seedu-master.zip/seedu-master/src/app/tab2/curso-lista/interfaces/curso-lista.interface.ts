export interface CursoInterface {
  id: string;
  nome: string;
  image: string;
  progresso: number;
}
